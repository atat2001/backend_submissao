"""
Sample program for testing. Receiving and outputting multiple lines. It
receives 2 numbers, prints their adition and their multiplication.
"""

num1 = int(input())
num2 = int(input())
print(num1 + num2)
print(num1 * num2)
