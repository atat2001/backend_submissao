"""
Sample program for testing. Receives an integer as an input and prints that
input + 1.
"""


number = int(input())
print(number + 1)
