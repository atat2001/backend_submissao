# LEET CODE
* Big Brain Time: 23pts
* Maltrapilhos: 22pts
* Social_Enjoyers: 19pts
* Saucy Goats: 19pts
* 0x455A: 19pts
* Python goes 'b' + 'r' * 10: 18pts
* Caranguejos: 16pts
* 2PES: 15pts
* Barquinho: 11pts
* Girafas de plasticina: 11pts
* Segmentation Fault: 11pts
* King Size: 0pts (Problma com plataforma e Java)
* Peperoni Powet: 0pts (No show)
* NunoDev: 0pts (No show)


# PROJECT
* Barquinho: 1o lugar (URL_SHORTNER)
* Maltrapilhos: 2o Lugar (DIGITAL_WALLET)
* Caranguejos: 3o Lugar (URL_SHORTNER)
