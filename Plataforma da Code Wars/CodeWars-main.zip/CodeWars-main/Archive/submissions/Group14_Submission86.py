#!/bin/python3

galhos = int(input())
if galhos % 4 == 0:
    print("vencedor")
else:
    print("perdedor")
