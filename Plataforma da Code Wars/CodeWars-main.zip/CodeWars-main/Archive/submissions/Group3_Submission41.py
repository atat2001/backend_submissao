user_input = input()

n_galhos = user_input
""" galhos_meus = 0 
galhos_toze = 0 """
if n_galhos % 4 == 0:
    output = print("vencedor")
else:
    output = print("perdedor")


print(output)