rows, caracter = input().split(",")

for i in range(int(rows), 0, -1):
  print(caracter*i)