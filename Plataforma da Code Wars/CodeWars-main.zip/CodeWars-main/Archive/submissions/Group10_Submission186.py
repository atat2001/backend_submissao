n1,n2,n3,n4 = input().split(",")

n1,n2,n3,n4 = int(n1),int(n2),int(n3),int(n4)

print((n4-n3)-(n1-n2))