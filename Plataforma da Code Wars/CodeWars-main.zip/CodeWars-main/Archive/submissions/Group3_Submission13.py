user_input = input()

n_galhos = user_input
""" galhos_meus = 0 
galhos_toze = 0 """

if n_galhos % 2 == 0:      #numero par
    output = "vencedor"
else:                      #umero impar
    output = "perdedor"


print(output)