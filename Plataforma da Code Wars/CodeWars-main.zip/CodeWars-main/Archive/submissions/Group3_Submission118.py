user_input = input().split(',')
print(user_input)
for i in range(len(user_input)):
    user_input[i] = int(user_input[i])

print(user_input)


nrs = [user_input[1]] + [user_input[2]]

lista_mult = []
for i in range(1,100):
    if int(nrs[0])* i not in lista_mult:
        lista_mult += [int(nrs[0])* i]
    if int(nrs[1])* i not in lista_mult:
        lista_mult += [int(nrs[1]) * i]

lista_mult.sort()

output = lista_mult[nrs[0]]
print(lista_mult)







print(output)