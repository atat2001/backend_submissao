from random import randint 
galhos = int(input("Numero de galhos: "))
if galhos % 4 != 0:
    print("vencedor")
else:
    print("perdedor")