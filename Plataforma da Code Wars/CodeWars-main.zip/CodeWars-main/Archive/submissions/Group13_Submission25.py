x = input()
if(x%4 == 0):
    print("vencedor")

