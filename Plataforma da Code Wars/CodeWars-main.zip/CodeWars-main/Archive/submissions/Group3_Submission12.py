user_input = input()

ParqueEstacionamento = []

Carro = {"matricula": matricula , "EmUso": uso }

def aceitarCarro(Carro, ParqueEstacionamento):
    ParqueEstacionamento.append([])


print(output)