user_input = input()
user_input = int(user_input)
if user_input % 4 == 0:
    print("vencedor")
else:
    print("perdedor")