# CodeWars 2022
Neste repositório reside todo o conteúdo programático para as CodeWars de 2022.

Contributors: Pedro Perpétua (https://pedroperpetua.com)



# BACKEND
## Security
ADMIN WEBSITE: https://codewars-api.systems-group.org/admin/

ADMIN CREDENTIALS:

    user: admin
    password: dbe79E-zY?bd


DROPLET CREDENTIALS:

    ip: 178.62.75.124

    user: root
    password: 5P!,V8_U/cPBkXR

    user: code-wars
    password: 5P!,V8_U/cPBkXR


SSH:

    The key fingerprint is:
    SHA256:KtjtOCq/S+3sttuuitnS0Upe2TrVAjxaK07qrhvtTfY root@ubuntu-backend-cw
    The key's randomart image is:
    +---[RSA 3072]----+
    |                 |
    |                 |
    |   .             |
    |    =            |
    |   + * .S        |
    | .*+=.+..        |
    |.B+=*oo.         |
    |+B=*=*           |
    |OBOBXBE          |
    +----[SHA256]-----+

    PUBLIC RSA:
    ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDNTwZUer4snvxGBmYiFrxQEnQUHPA9XtKsV9Y+7UiBzN1iBrYfkYOhr9vaAdLREtqTyfWoXZeyUc1Q81iar/XK6vyfNqXAIBE1rIgOJHhYDqoUGu6fbUkfKzVdey+F7h6cy3p4bZSxdj1F4Qx9DQKqm>

### Useful links:
- https://www.digitalocean.com/community/tutorials/how-to-secure-nginx-with-let-s-encrypt-on-ubuntu-20-04
- https://www.digitalocean.com/community/tutorials/how-to-set-up-django-with-postgres-nginx-and-gunicorn-on-ubuntu-20-04


## Notas de implementação
Detalhes sobre a base de dados podem ser encontradas em protocol.drawio. A base de dados utiliza SQLITE3.

Dados podem ser carregados através de fixtures na app "core".

Para questões de simplificação, é utilizada uma autenticação simples não-segura em que as passwords são guardadas em plain-text e enviadas nas post requests; Estas passwords devem ser geradas automaticamente para todos os grupos, pelo que o conceito de "conta de utilizador" não existe no sistema.

Línguagens suportadas:
- Python (.py)
- Javascript (.js)
- Java (.java)
- C (.c)
- C++ (.cpp)

O servidor atua como um serviço REST que expõe dois endpoints:
- /api/challenges
    - **[GET]** Obter a lista de challenges ativos
    - **[GET] /api/challenges/id:int** retorna a descrição do challenge específico
- /api/submissions
    - **[POST]** Grupo fazer uma nova submissao
        - group: int - numero do grupo
        - password: string - password do grupo
        - file: file - ficheiro da submissão
        - challenge: int - id do desafio a que estão a fazer a submissão
    - **[POST] /api/submissions/list** retorna a lista de submissões feitas por um grupo.
        - group: int - numero do grupo
        - password: string - password do grupo
    - **[POST] /api/submissions/results** retorna os resultados de leet code feitas por um grupo.
        - group: int - numero do grupo
        - password: string - password do grupo
    - **[GET] /api/submissions/final_results** retorna uma página com os resultados de todos os grupos para leetcode. Requer admin login.


## config.env
As seguintes configurações encontram-se em config.env - aqui tem os seus default values.
    PYTHON=python # Comando para invocar python.
    VENV_DIR=Backend/.venv/Scripts # Localização para ativar o VirtualEnv.
    HOST=0.0.0.0 # Endereço do host para produção.
    BACKEND_ADDRESS=0.0.0.0 # Endereço a que o servidor Django dá bind.
    BACKEND_PORT=8000 # Porta exposta pelo servidor Django.


## Makefile
    Make install: instala as depêndencias do servidor num virtual environment em Backend/.venv
    Make uninstall: remove o virtual environment em Backend/.venv
    Make run: corre o servidor localmente.
    Make migrate: corre as migrações do servidor de Django.
    Make test: corre a test suite.
    Make admin: permite criar um superuser na base de dados.
    Make clean_db: limpa a base de dados.
    Make load_data: carrega todas as fixtures.



# FRONTEND
O Frontend é deployed através de Github Pages.

# ARCHIVE
Os resultadps o evento realizado a 12/03/2022 estão arquivados em archive, bem como as sumbissões, desafios, e registos dos participantes e grupos.