from django.contrib import admin
from django.contrib import admin

from .models import Conta

admin.site.register(Conta)

# Register your models here.

# from .models import Question

# Register your models here.

# admin.site.register(Question)

# from .models import Money, Nr_Conta, Book, BookInstance

# admin.site.register(Money)
# admin.site.register(Nr_Conta)
# admin.site.register(Tipo_Conta)
# admin.site.register(Localidade)
# admin.site.register(Nome)
# admin.site.register(Email)
# admin.site.register(Localidade)

