from datetime import date
class Currency():
    #c = CurrencyConverter()
    c_rates = dict()

    def _init_(self, value: float, coininput: str = "$", conversion: float = 0):
        if coininput == "USD" or coininput == "usd" or coininput == "$":
            name = 'USD'
        elif coininput == "EUR" or coininput == "eur" or coininput == "€":
            name = 'EUR'
        elif coininput == "BIT" or coininput == "bit":
            name = 'BIT'
        elif coininput == "RMB" or coininput == "rmb" or coininput == "CNY" or coininput == "cny":
            name = 'CNY'
        elif coininput == "rub" or coininput == "RUB":
            name = 'RUB'
        elif coininput == "gbp" or coininput == "GBP":
            name = "GBP"
        else:
            name = coininput
            Currency.c_rates.update({coininput: conversion})
        self.__val = value
        self.__type = name
        self.__conversion = conversion
    
    def val(self):
        return self.__val

    def show(self):
        return self.__type

    def add(self, value: float):
        self.val += value

    def sub(self, value: float):
        self.val -= value
    
    def convertusd(self):
        final = Currency.c.convert('USD', self.__type, self.__val)
        self.__val = final
        self.__type = 'USD'
        return self

    def converteur(self):
        final = Currency.c.convert('EUR', self.__type, self.__val)
        self.__val = final
        self.__type = 'EUR'
        return self

    def convertgbp(self):
        final = Currency.c.convert('GBP', self.__type, self.__val)
        self.__val = final
        self.__type = 'GBP'
        return self

    def convertrub(self):
        final = Currency.c.convert('RUB', self.__type, self.__val)
        self.__val = final
        self.__type = 'RUB'
        return self

    def convertcny(self):
        final = Currency.c.convert('CNY', self.__type, self.__val)
        self.__val = final
        self.__type = 'CNY'
        return self

    def convertbit(self):
        #b = BtcConverter()
        b.convert_to_btc(self.__val, self.__type)

    def convertcostusd(self):
        if self.__conversion == 0:
            return self
        self.__type = "USD"
        self.__val *= self.__conversion

    def usdcust(self, name: str):
        # dar um erro?
        if self.__type == "USD" and name in Currency.c_rates.keys():
            self.__val /= Currency.c_rates[name]
        return self

class Banco():
    Data = date(2022, 1, 1)
    Data.__format__('%Y/%m/%d')
    contas = []
    Ids_count = 0
    def __init__(self, TipoDeConta: str, Montante: float, Moeda: str, Localidade:
        str, nome: str, email: str, telefone: int, password: str):
        self.__Id = Banco.Ids_count
        self.__password = password
        self.__TipoDeConta = TipoDeConta
        self.__Carteira = {Currency(Montante, Moeda).show() : Currency(Montante, Moeda)}
        self.__Pais = Localidade
        self.__nome = nome
        self.__email = email
        self.__telefone = telefone
        self.__historico = []
        Banco.contas += [self]
    
    def Id(self):
        return self.__Id

    def TipoDeConta(self):
        return self.__TipoDeConta

    def Nome(self):
        return self.__nome

    def Email(self):
        return self.__email

    def Telefone(self):
        return self.__telefone
    
    def Pais(self):
        return self.__Pais

    def Conversao(self, Moeda1: str, Moeda2: str, Montante):
        self.__Carteira[Moeda1].sub(Montante)
        self.__Carteira[Moeda2].add(convert(Moeda1, Moeda2, Montante * 0.98))

    def Pagamento(self, Montante: float, Moeda: str, Empresa: str):
        #self.__Carteira??
        if Moeda not in self.__Carteira:
            raise ValueError("Pagamento com moeda incompatível")
        self.__Carteira[Moeda].sub(Montante)
        #Empresa tem de receber dinheiro
        self.__historico.append(["Pagamento de serviços", Empresa, Montante, Moeda, Banco.Data])
        Banco.Data += Banco.Data + timedelta(days = 1)

    
    def Transferencia(self, Conta2, Montante: float, Moeda: str):
        if Moeda not in self.__Carteira:
            raise ValueError("Pagamento com moeda incompatível")
        if self.TipoDeConta() == "Premium":
            recebido = Montante
            self.__Carteira[Moeda].sub(Montante)
            Conta2.__Carteira[Moeda].add(recebido)

        #mudar para continentes
        elif self.Pais() == Conta2.Pais():
            recebido = Montante * 0.95
            self.__Carteira[Moeda].sub(Montante)
            Conta2.__Carteira[Moeda].add(recebido)

        elif self.TipoDeConta() == "Normal":
            recebido = Montante * 0.97
            self.__Carteira[Moeda].sub(Montante)
            Conta2.__Carteira[Moeda].add(recebido)

        self.__historico.append(["Transferência Bancária", Conta2.Id(), Montante, Moeda, Banco.Data])
        Conta2.__historico.append(["Transferência Bancária", self.Id(), recebido , Moeda, Banco.Data])
        Banco.Data += Banco.Data + timedelta(days = 1)
    
    def Moedas(self):
        return [i for i in self.__Carteira]

    def Saldo(self, Moeda: str):
        return self.__Carteira[Moeda].val()







class Banco():
    Data = date(2022, 1, 1)
    Data.__format__('%Y/%m/%d')
    contas = []
    Ids_count = 0
    clientes = {}
    def __init__(self, nome: str, email: str, password: str,  telemovel, deposito, pais, TipoDeConta: str, Montante: float, Moeda: str):
        self._password = password
        self._nome = nome 
        self._email = email
        self._telemovel = telemovel
        self._deposito = deposito
        self._pais = pais
        self.__TipoDeConta = TipoDeConta 
        #self.__Carteira = {Currency(Montante, Moeda).show() : Currency(Montante, Moeda)}
        Banco.clientes.update({email: (password, self)})
        self.__Id = Banco.Ids_count
        self.__historico = []
        Banco.contas += [self]

    def informacoes_pessoais(self):
        return f"Nome: {self._nome}\nE-mail : {self._email}\nTelemovel : \n{self._telemovel}\nPais : {self._pais}"
    

    def update_infor_pessoais(self, nome, email, telemovel, pais, password):
        self._password = password
        self._nome = nome 
        self._email = email
        self._telemovel = telemovel
        self._pais = pais 
    
    @classmethod
    def match_client_password(cls, email, password):
        return email in Banco.clientes and Banco.clientes[email][0] == password
    
    @classmethod
    def associate_cliente(cls, email):
        return cls.clientes[email][1]
    
    Data = date(2022, 1, 1)
    Data.__format__('%Y/%m/%d')
    contas = []
    Ids_count = 0
    
    
    def Id(self):
        return self.__Id

    def TipoDeConta(self):
        return self.__TipoDeConta

    def Conversao(self, Moeda1: str, Moeda2: str, Montante):
        self.__Carteira[Moeda1].sub(Montante)
        self.__Carteira[Moeda2].add(convert(Moeda1, Moeda2, Montante * 0.98))

    def Pagamento(self, Montante: float, Moeda: str, Empresa: str):
        #self.__Carteira??
        if Moeda not in self.__Carteira:
            raise ValueError("Pagamento com moeda incompatível")
        self.__Carteira[Moeda].sub(Montante)
        #Empresa tem de receber dinheiro
        self.__historico.append(["Pagamento de serviços", Empresa, Montante, Moeda, Banco.Data])
        Banco.Data += Banco.Data + timedelta(days = 1)

    
    def Transferencia(self, Conta2, Montante: float, Moeda: str):
        if Moeda not in self.__Carteira:
            raise ValueError("Pagamento com moeda incompatível")
        if self.TipoDeConta() == "Premium":
            recebido = Montante
            self.__Carteira[Moeda].sub(Montante)
            Conta2.__Carteira[Moeda].add(recebido)

        #mudar para continentes
        elif self.Pais() == Conta2.Pais():
            recebido = Montante * 0.95
            self.__Carteira[Moeda].sub(Montante)
            Conta2.__Carteira[Moeda].add(recebido)

        elif self.TipoDeConta() == "Normal":
            recebido = Montante * 0.97
            self.__Carteira[Moeda].sub(Montante)
            Conta2.__Carteira[Moeda].add(recebido)

        self.__historico.append(["Transferência Bancária", Conta2.Id(), Montante, Moeda, Banco.Data])
        Conta2.__historico.append(["Transferência Bancária", self.Id(), recebido , Moeda, Banco.Data])
        Banco.Data += Banco.Data + timedelta(days = 1)
    
    def Moedas(self):
        return [i for i in self.__Carteira]

    def Saldo(self, Moeda: str):
        return self.__Carteira[Moeda].val()
    

        
        
