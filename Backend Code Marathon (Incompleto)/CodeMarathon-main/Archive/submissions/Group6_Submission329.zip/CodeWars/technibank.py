import datetime
from sre_constants import SRE_FLAG_DOTALL
from classes import *
import os
import time
lista_test = [111]
password_test = 111
client = Banco("PEDRO", "p", "111", 111, 111, "portugal", "Pessoal", 130, "$")
def reloading():
    os.system("clear")
    print("Opção não disponível")
    print("Going to home page in 3s...")
    time.sleep(1)
    print("Going to home page in 2s...")
    time.sleep(1)
    print("Going to home page in 1s...")
    time.sleep(1)
    os.system("clear")
    return ""

while True:
    print("Bem-Vindo")
    print("-----------------")
    print("Escolha uma opção: ")
    print("-----------------")
    print("- Entre na sua conta de cliente (1)")
    print("- Criar uma conta (2)")
    in_value = input("- ")
    try:
        value = int(in_value)
        os.system("clear")
        if value in range(1, 3):
            if value == 1:
                mail_cliente = input("Escreve o seu email : ")
                password = input("Escreve a sua password : ")
                os.system("clear")
                if Banco.match_client_password(mail_cliente, password):
                    cliente = Banco.associate_cliente(mail_cliente)
                    while True:
                        print("Escolha uma opção: ")
                        print("-----------------")
                        print("- Consultar Informações Pessoais (1)")
                        print("- Consultar Informações de Conta (2)")
                        print("- Consultar Saldo (3)")
                        print("- Historico de Operacoes (4)")
                        print("- Transferencias (5)")
                        print("- Pagamento de Serviços (6)")
                        print("- Adicionar Moedas a conta (7)")
                        print("- Atualizar Informacoes Pessoais (8)")
                        print("- Exit (10)")
                        try:
                            value = int(input("- "))
                            if value in range(1, 9):
                                #Operations
                                if value == 1: #Inform Pessoais
                                    os.system("clear")
                                    print(cliente.informacoes_pessoais())
                                    break
                                if value == 2: #Inform de Contas
                                    os.system("clear")
                                    print(cliente.TipoDeConta())
                                    break
                                if value == 3: #Saldo
                                    os.system("clear")
                                    print(cliente.Saldo("$"))
                                    break
                                if value == 4: #Hist de Opera
                                    os.system("clear")
                                    print(cliente.Moedas())
                                    time.sleep(3)
                                    break
                                if value == 5: #Transferencias
                                    os.system("clear")
                                    print("Em manutenção")
                                    time.sleep(3)
                                    break
                                if value == 6: #Pagamento de Serviços
                                    os.system("clear")
                                    print("Em manutenção")
                                    time.sleep(3)
                                    break
                                if value == 7: #Adicionar Moedas
                                    os.system("clear")
                                    print("Em manutenção")
                                    time.sleep(3)
                                    break
                                if value == 8: #Atualizar Inform Pessoais
                                    os.system("clear")
                                    print("Introduza as novas informações: ")
                                    nome = input("Nome : ")
                                    email = input("E-mail: ")
                                    n_telemovel = input("N Telemovel: ") 
                                    pais = input("Pais: ")
                                    password = input("Password: ")
                                    cliente.update_infor_pessoais(nome, email, n_telemovel, pais, password)
                                    os.system("clear")
                                    print("Novas Informacoes: ")
                                    print(cliente.informacoes_pessoais())
                                    time.sleep(2)
                                    break
                                #Operations
                            if value == 10:
                                os.system("clear")
                                break
                            else:
                                print(reloading())
                        except:
                            print(reloading())
                else:
                    print("User not found or wrong password")
            if value == 2:
                os.system("clear")
                nome = input("Nome : ")
                email = input("E-mail: ")
                n_telemovel = int(input("N Telemovel: ") )
                pais = input("Pais: ")
                tipo_conta = input("Tipo de conta (Normal ou Premium): ")
                saldo = float(input("Saldo : "))
                moeda = input("Moeda : ")
                password = input("Password : ")
                cliente = Banco(nome, email, password, n_telemovel, saldo, pais, tipo_conta, saldo, moeda)
                print("Conta criada\nEntre na sua conta: \n")
                time.sleep(1)
                os.system("clear")
            print(" ")
        else:
            print(reloading())
    except:
        print(reloading())




    
