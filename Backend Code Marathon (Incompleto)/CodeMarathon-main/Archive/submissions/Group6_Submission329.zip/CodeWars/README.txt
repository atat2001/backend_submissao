TechniBank - Sistema de contas


Para entrar no interface de server do sistema de contas bancárias do TechniBank
corra num terminal o comando:

python3 TechniBank.py

Deve aparecer um terminal com  as seguintes opções:

- Entre na sua conta de cliente (1)
- Criar uma conta (2)

Inserindo os números indicados em cada opção seguidos de "Enter" permitem prosseguir as suas 
operações neste terminal.

Opções:

- Entre na sua conta de cliente (1)

Ao selecionar esta opção encontrará um novo conjunto de opções que lhe permitirá aceder a todas
as suas informações pessoais e de conta:

- Consultar Informações Pessoais (1)
- Consultar Informações de Conta (2)
- Consultar Saldo (3)
- Historico de Operacoes (4)
- Transferencias (5)
- Pagamento de Serviços (6)
- Adicionar Moedas a conta (7)
- Atualizar Informacoes Pessoais (8)
- Exit (10)


Uma vez mais os números em frente das funções indicam cada um dos processos possíveis

A inserção de um input inválido no terminal causará o reinício do terminal


- Criar uma conta (2)

Ao escolher esta opção os seguintes dados são pedidos ao utilizador:

Nome:
Email:
Telemóvel:
País:
Moeda:
Montante:
Tipo de Conta:


A partir daqui o cliente possuirá uma conta ativa à qual poderá aceder a partir das opções anteriores.







