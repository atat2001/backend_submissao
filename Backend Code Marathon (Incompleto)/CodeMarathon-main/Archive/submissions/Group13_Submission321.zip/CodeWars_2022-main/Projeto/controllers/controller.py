
def adder(x,y):
    return x + y