# CodeWars_2022

O programa corre em Python
Para correr é necessario instalar as seguintes packages: (pycountry-convert  e datetime)

`pip install pycountry-convert datetime:`

ou

`pip install requirements.txt`

Para correr:
`python main.py`


## Como criar um novo user?

Para criar um novo user basta abrir o Menu entitulado Users e escolher a opcao entitulada de create user.


No "models" temos as classes referentes aos objetos que utilizamos neste Projeto, nomeadamente as contas, o banco, a data, as operacoes e o user.

No "views" encontra-se o interface de terminal que iremos utilizar.


Uma conta encontra-se definida pelo seu:

- Balanco
- User que detem a conta
- O id da conta
- Pelas operacoes feitas nesta
- pela localizacao e continente a que pertence
- Se é premium




Um banco encontra-se definida pelas suas:

Contas

A data corrente

O proximo ID a atribuir

Os seus Utilizadores




Uma data encontra-se definida pelo dia mes e ano referente


As operacoes estao definidas pela:

Data a que foi feita

quantidade transferida

e a conta de origem






