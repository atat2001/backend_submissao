# URL SHORTNER

## API

### shorten: `POST /shorten`
    URL: `/shorten`
    Method: `POST`
    Data:
        ```json
        {
            url: string
        }
        ```
    Response:
        ```json
        {
            url: string
        }
        ```

### unshorten: `POST /unshorten`
    URL: `/unshorten`
    Method: `POST`
    Data:
        ```json
        {
            url: string
        }
        ```
    Response:
        ```json
        {
            url: string
        }
        ```

### search: `POST /search`
    URL: `/search`
    Method: `POST`
    Data:
        ```json
        {
            term: string
        }
        ```

    Response:
        ```json
        {
            urls: [
                {
                    shortened_url: string, 
                    url: string
                }
            ]
        }
        ```

### stats: `GET /stats`
    URL: `/stats`
    Method: `GET`
    Response:
        ```json
        {
            urls_stored: int,
            terms: [
                {
                    shortened_url: string,
                    url: string
            }
            ]
        }
        ```
