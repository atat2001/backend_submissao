#!/usr/bin/env python3

import json
import uuid
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
cors = CORS(app)


class UrlStore():
    shortened = {}
    search_terms: dict[str, int] = {}


def url_hash():
    return uuid.uuid4().hex[:12]


@app.route('/shorten', methods=['POST'])
def shorten():
    req = json.loads(request.data)
    if 'url' not in req:
        return jsonify({'error': 'missing url attribute'})

    url = req['url']
    # TODO: check if this already exists
    shortened_url = f'https://0x455A.pt/{url_hash()}'
    UrlStore.shortened[shortened_url] = url
    return jsonify({'url': shortened_url})


@app.route('/unshorten', methods=['POST'])
def unshorten():
    req = json.loads(request.data)
    if 'url' not in req:
        response = jsonify({'error': 'missing url attribute'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    shortened_url = req['url']
    if shortened_url not in UrlStore.shortened:
        return jsonify({'error': 'unknown url'})

    return jsonify({'url': UrlStore.shortened[shortened_url]})


@app.route('/search', methods=['POST'])
def search():
    req = json.loads(request.data)
    if 'term' not in req:
        return jsonify({'error': 'missing term attribute'})

    search_term = req['term']
    if search_term not in UrlStore.search_terms:
        UrlStore.search_terms[search_term] = 0

    UrlStore.search_terms[search_term] += 1

    urls = {}
    for shortened_url, url in UrlStore.shortened.items():
        if shortened_url not in url and search_term in url:
            urls[shortened_url] = url

    response = {'urls': []}
    for shortened_url, url in urls.items():
        response['urls'].append({'shortened_url': shortened_url, 'url': url})

    return jsonify(response)


@app.route('/stats', methods=['GET'])
def stats():
    return {
        'urls_stored':
        len(UrlStore.shortened),
        'terms':
        sorted(UrlStore.search_terms.items(),
               key=lambda item: item[1],
               reverse=True),
    }


app.run(debug=True)
